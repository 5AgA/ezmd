create trigger PROFESSOR_ID_TRIGGER
    before insert
    on PROFESSOR
    for each row
BEGIN
   :NEW.professor_id := PROFESSOR_SEQ.NEXTVAL;
END;
/

