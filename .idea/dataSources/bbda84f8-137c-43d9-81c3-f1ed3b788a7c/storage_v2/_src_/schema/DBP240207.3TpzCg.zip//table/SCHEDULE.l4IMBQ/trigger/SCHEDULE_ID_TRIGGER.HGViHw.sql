create trigger SCHEDULE_ID_TRIGGER
    before insert
    on SCHEDULE
    for each row
BEGIN
   :NEW.schedule_id := SCHEDULE_SEQ.NEXTVAL;
END;
/

