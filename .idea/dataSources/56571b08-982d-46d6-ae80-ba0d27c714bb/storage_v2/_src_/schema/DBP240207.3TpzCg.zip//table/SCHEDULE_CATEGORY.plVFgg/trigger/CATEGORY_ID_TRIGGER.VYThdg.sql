create trigger CATEGORY_ID_TRIGGER
    before insert
    on SCHEDULE_CATEGORY
    for each row
BEGIN
   :NEW.category_id := CATEGORY_SEQ.NEXTVAL;
END;
/

