create trigger INTERVIEW_ID_TRIGGER
    before insert
    on INTERVIEW
    for each row
BEGIN
   :NEW.interview_id := INTERVIEW_SEQ.NEXTVAL;
END;
/

