create trigger PROFESSOR_REVIEW_ID_TRIGGER
    before insert
    on PROFESSOR_REVIEW
    for each row
BEGIN
   :NEW.review_id := PROFESSOR_REVIEW_SEQ.NEXTVAL;
END;
/

